# -*- encoding : utf-8 -*-
require 'test_helper'

class ExelsHelperTest < ActionView::TestCase
end
