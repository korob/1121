# -*- encoding : utf-8 -*-
require 'test_helper'

class FirmrollsHelperTest < ActionView::TestCase
end
