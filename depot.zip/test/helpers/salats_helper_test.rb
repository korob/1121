# -*- encoding : utf-8 -*-
require 'test_helper'

class SalatsHelperTest < ActionView::TestCase
end
