# -*- encoding : utf-8 -*-
require 'test_helper'

class NapsHelperTest < ActionView::TestCase
end
