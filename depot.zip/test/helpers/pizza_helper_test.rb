require 'test_helper'

class PizzaHelperTest < ActionView::TestCase
end
