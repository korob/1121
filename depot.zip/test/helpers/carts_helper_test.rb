# -*- encoding : utf-8 -*-
require 'test_helper'

class CartsHelperTest < ActionView::TestCase
end
