# -*- encoding : utf-8 -*-
require 'test_helper'

class AsssHelperTest < ActionView::TestCase
end
