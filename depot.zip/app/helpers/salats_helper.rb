# -*- encoding : utf-8 -*-
module SalatsHelper
end
