# -*- encoding : utf-8 -*-
module AdminHelper
end
