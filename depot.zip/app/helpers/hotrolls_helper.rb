# -*- encoding : utf-8 -*-
module HotrollsHelper
end
