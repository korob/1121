# -*- encoding : utf-8 -*-
module AsssHelper
end
