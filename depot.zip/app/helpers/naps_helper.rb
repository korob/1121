# -*- encoding : utf-8 -*-
module NapsHelper
end
