# -*- encoding : utf-8 -*-
module SushisHelper
end
